test = {
  'name': 'question 1iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> squares1
          [0.0, 1.0, 4.0, 9.0, 1.0, 4.0, 9.0, 16.0, 4.0, 9.0, 16.0, 25.0]
          """,
          'hidden': False,
          'locked': False
        }		
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
