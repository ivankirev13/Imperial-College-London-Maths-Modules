test = {
  'name': 'question 4g',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> my_primes1(100) == [2,  3,  5,  7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> my_primes1(101) == [2,  3,  5,  7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101]
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> my_primes1(121) == [2,   3,   5,   7,  11,  13,  17,  19,  23,  29,  31,  37,  41, 43,  47,  53,  59,  61,  67,  71,  73,  79,  83,  89,  97, 101, 103, 107, 109, 113]
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import array, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
