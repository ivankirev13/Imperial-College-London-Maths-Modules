test = {
  'name': 'question 4e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> all(ints4 == array([ 2,  3,  5,  7,  9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(ints4, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': 'from numpy import array, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
