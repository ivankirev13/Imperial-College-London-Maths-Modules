test = {
  'name': 'question 3d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question3d_answer
          3
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
