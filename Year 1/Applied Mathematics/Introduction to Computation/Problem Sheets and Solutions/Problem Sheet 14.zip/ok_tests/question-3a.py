test = {
  'name': 'question 3a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(sine_map1(0.3, 1.0, 0.3), 0.44863465427186855)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(sine_map2(0.3, 1.0, 0.3), 0.44863465427186855)
          True
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
