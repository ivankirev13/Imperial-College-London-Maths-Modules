test = {
  'name': 'question 1iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (mat1 == fromfunction(lambda x, y: x + y, (3, 4))).all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(mat1, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }		
      ],
      'scored': True,
      'setup': 'from numpy import fromfunction, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
