test = {
  'name': 'question 2a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(simpsons_rule1(sin, 0.0, pi/2), 1.0000033922209004)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(simpsons_rule1(lambda x: x**5-x**4, 0.0, 1.0, 6), -0.03317901234567901)
          True
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': 'from math import sin, pi\nfrom numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
