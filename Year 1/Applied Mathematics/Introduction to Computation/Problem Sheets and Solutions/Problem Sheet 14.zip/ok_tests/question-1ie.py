test = {
  'name': 'question 1ie',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> all(square_array == array([97, 98, 99, 100, 101, 102])**2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(square_array, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }		
      ],
      'scored': True,
      'setup': 'from numpy import array, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
