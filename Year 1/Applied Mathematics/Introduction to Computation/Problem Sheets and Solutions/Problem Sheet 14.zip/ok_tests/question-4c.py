test = {
  'name': 'question 4c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> all(ints2 == array([ 2,  3,  4,  6,  7,  8,  9, 11, 12, 13, 14, 16, 17, 18, 19, 21, 22, 23, 24, 26, 27, 28, 29]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(ints2, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': 'from numpy import array, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
