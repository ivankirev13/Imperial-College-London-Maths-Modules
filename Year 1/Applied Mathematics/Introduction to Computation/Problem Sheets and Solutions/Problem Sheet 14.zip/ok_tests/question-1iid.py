test = {
  'name': 'question 1iid',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (mat2 == fromfunction(lambda x, y: abs(x-y), (3,4))).all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(mat2, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },	
        {
          'code': r"""
          >>> (mat3 == fromfunction(lambda x, y: y**2, (1,4))).all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(mat3, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },	
        {
          'code': r"""
          >>> (mat4 == fromfunction(lambda x, y: y**2 - x**2, (4,4))).all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(mat4, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import fromfunction, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
