test = {
  'name': 'question 3e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(rotation_number_list([0.3, 0.4, 0.5], 1.0, 0.3, 10), [0.2569508387568104, 0.39452971322417907, 0.47005157794159713])
          True
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': 'from numpy import allclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
