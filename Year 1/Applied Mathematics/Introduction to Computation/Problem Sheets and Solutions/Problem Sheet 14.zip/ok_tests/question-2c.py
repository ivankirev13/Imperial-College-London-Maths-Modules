test = {
  'name': 'question 2c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2c_answer
          1
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
