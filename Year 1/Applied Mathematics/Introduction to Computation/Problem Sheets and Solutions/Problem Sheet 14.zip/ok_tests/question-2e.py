test = {
  'name': 'question 2e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2e_answer
          1
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
