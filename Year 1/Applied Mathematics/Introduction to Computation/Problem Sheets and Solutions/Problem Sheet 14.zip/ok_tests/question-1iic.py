test = {
  'name': 'question 1iic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> squares2
          [0.0, 1.0, 4.0, 1.0, 4.0, 9.0, 4.0, 9.0, 16.0, 9.0, 16.0, 25.0]
          """,
          'hidden': False,
          'locked': False
        }		
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
