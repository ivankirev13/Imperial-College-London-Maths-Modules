test = {
  'name': 'question 2f',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2f_answer
          3
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
