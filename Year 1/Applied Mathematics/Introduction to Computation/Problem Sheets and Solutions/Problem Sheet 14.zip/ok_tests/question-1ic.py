test = {
  'name': 'question 1ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> range_squares
          [9409, 9604, 9801, 10000, 10201, 10404]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_squares
          [9409, 9604, 9801, 10000, 10201, 10404]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> array_squares
          [9409, 9604, 9801, 10000, 10201, 10404]
          """,
          'hidden': False,
          'locked': False
        }		
      ],
      'scored': True,
      'setup': 'from numpy import array, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
