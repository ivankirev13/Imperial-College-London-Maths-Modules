test = {
  'name': 'question 2d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2d_answer
          2
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
