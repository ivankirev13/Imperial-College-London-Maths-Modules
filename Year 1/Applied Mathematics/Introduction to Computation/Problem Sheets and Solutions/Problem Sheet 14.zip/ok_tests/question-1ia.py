test = {
  'name': 'question 1ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> myrange == range(97, 103)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> mylist
          [97, 98, 99, 100, 101, 102]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> all(myarray == array([97, 98, 99, 100, 101, 102]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(myarray, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }		
      ],
      'scored': True,
      'setup': 'from numpy import array, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
