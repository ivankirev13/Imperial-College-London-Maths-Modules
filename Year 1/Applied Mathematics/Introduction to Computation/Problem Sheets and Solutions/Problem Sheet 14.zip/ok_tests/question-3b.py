test = {
  'name': 'question 3b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question3b_answer
          3
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
