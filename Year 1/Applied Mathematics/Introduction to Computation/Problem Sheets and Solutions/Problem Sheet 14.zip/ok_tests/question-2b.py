test = {
  'name': 'question 2b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(simpsons_rule2(sin, 0.0, pi/2), 1.0000033922209004)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(simpsons_rule2(lambda x: x**5-x**4, 0.0, 1.0, 6), -0.03317901234567901)
          True
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': 'from numpy import sin, pi, isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
