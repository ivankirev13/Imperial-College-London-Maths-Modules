test = {
  'name': 'question 4b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> all(bool1 == array([False, False, False,  True, False, False, False, False,  True, False, False, False, False, True, False, False, False, False, True, False, False, False, False,  True, False, False, False, False,  True]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(bool1, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': 'from numpy import array, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
