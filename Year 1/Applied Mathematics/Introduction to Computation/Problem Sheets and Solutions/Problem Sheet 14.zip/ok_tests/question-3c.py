test = {
  'name': 'question 3c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(rotation_number1(0.3, 1.0, 0.3, 1), 0.14863465427186856)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(rotation_number2(0.3, 1.0, 0.3, 1), 0.14863465427186856)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(rotation_number1(0.3, 1.0, 0.3, 10), 0.2569508387568104)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(rotation_number2(0.3, 1.0, 0.3, 10), 0.2569508387568104)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(rotation_number1(0.3, 1.0, 0.3), 0.2687236705645652)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(rotation_number2(0.3, 1.0, 0.3), 0.2687236705645652)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(rotation_number2(array([0.3, 0.4, 0.5]), 1.0, 0.3, 10), array([0.2569508387568104, 0.39452971322417907, 0.47005157794159713]))
          True
          """,
          'hidden': False,
          'locked': False
        }	
      ],
      'scored': True,
      'setup': 'from numpy import isclose, allclose, array',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
