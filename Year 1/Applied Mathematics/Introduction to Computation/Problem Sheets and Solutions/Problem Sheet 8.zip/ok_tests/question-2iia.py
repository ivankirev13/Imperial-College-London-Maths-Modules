test = {
  'name': 'question 2iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> plaintext_numbers
          [39, 79, 79, 68, 0, 69, 86, 69, 78, 73, 78, 71, 12, 0, 45, 82, 0, 34, 79, 78, 68, 12, 0, 41, 7, 86, 69, 0, 66, 69, 69, 78, 0, 69, 88, 80, 69, 67, 84, 73, 78, 71, 0, 89, 79, 85, 14]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> ciphertext_numbers
          [18, 73, 73, 46, 0, 83, 47, 83, 36, 41, 36, 62, 64, 0, 50, 89, 0, 23, 73, 36, 46, 64, 0, 92, 69, 47, 83, 0, 67, 83, 83, 36, 0, 83, 26, 15, 83, 9, 68, 41, 36, 62, 0, 63, 73, 10, 43]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> ciphertext
          '2iiN sOsDID^` Ry 7iDN` |eOs cssD s:/s)dID^ _i*K'
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
