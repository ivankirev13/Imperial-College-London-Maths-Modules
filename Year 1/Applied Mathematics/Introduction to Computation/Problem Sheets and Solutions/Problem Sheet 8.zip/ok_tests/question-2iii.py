test = {
  'name': 'question 2iii',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> ciphertext
          '8.dka MaJtK#K, scake# #.t stKJJed['
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> d
          61
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> decrypt
          'Vodka Martini, shaken not stirred.'
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
