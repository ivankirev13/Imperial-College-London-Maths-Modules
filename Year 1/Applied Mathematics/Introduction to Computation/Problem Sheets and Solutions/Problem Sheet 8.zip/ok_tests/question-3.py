test = {
  'name': 'question 3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> comparesets(set(q3a_answer),correct_answer)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'correct_answer={(0, 1, 1), (0, 5, 5), (1, 3, 2), (3, 0, 3), (3, 4, 7), (5, 2, 7), (5, 6, 3), (0, 4, 4), (4, 4, 0), (6, 3, 5), (6, 7, 1), (1, 0, 1), (1, 4, 5), (3, 3, 0), (3, 7, 4), (5, 1, 4), (5, 5, 0), (2, 3, 1), (2, 7, 5), (6, 2, 4), (7, 1, 6), (0, 2, 2), (0, 6, 6), (2, 6, 4), (4, 1, 5), (4, 5, 1), (6, 0, 6), (6, 4, 2), (1, 7, 6), (3, 1, 2), (5, 7, 2), (7, 0, 7), (0, 3, 3), (0, 7, 7), (4, 0, 4), (7, 4, 3), (4, 7, 3), (3, 2, 1), (3, 6, 5), (5, 0, 5), (5, 4, 1), (2, 0, 2), (2, 4, 6), (6, 1, 7), (6, 5, 3), (1, 2, 3), (1, 6, 7), (7, 3, 4), (7, 7, 0), (0, 0, 0), (7, 6, 1), (2, 1, 3), (2, 5, 7), (6, 6, 0), (1, 1, 0), (1, 5, 4), (4, 2, 6), (4, 6, 2), (2, 2, 0), (3, 5, 6), (5, 3, 6), (7, 5, 2), (4, 3, 7), (7, 2, 5)}\ndef comparesets(set1,set2):\n   return set1==set2',
      'teardown': '',
      'type': 'doctest'
    },
	{
      'cases': [
        {
          'code': r"""
          >>> myisinstance(q3a_answer,list)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from types import BuiltinFunctionType\ndef myisinstance(func, type):\n   if isinstance(func, type):\n      return True\n   else:\n      raise TypeError("This does not seem to be a list of tuples.")',
      'teardown': '',
      'type': 'doctest'
    },
	{
      'cases': [
        {
          'code': r"""
          >>> q3b_answer
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
	{
      'cases': [
        {
          'code': r"""
          >>> istrue(q3c_answer)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'def istrue(bool):\n   if bool:\n      return True\n   else:\n      raise TypeError("Look again at part (c): the identity is 0, and every element is self-inverse.")',
      'teardown': '',
      'type': 'doctest'
    },
	{
      'cases': [
        {
          'code': r"""
          >>> isfalse(q3d_answer)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'def isfalse(bool):\n   if not bool:\n      return True\n   else:\n      raise TypeError("Look again at part (d): what if the powers of 2 are equal?")',
      'teardown': '',
      'type': 'doctest'
    },
	{
      'cases': [
        {
          'code': r"""
          >>> q3e_answer
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
