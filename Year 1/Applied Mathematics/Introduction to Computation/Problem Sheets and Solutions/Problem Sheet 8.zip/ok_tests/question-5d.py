test = {
  'name': 'question 5d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q5d_answer == 'prime' or q5d_answer == 'primes'
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
