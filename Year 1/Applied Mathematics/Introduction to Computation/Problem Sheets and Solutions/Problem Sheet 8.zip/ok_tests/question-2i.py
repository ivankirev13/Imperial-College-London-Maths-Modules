test = {
  'name': 'question 2i',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> ciphertext_numbers
          [82, 31, 37, 20, 7, 19, 11, 37, 15, 25, 37, 71, 21, 20, 10, 49, 37, 79, 7, 19, 11, 25, 37, 71, 21, 20, 10, 51]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> decrypt_numbers
          [45, 89, 0, 78, 65, 77, 69, 0, 73, 83, 0, 34, 79, 78, 68, 12, 0, 42, 65, 77, 69, 83, 0, 34, 79, 78, 68, 14]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> decrypt
          'My name is Bond, James Bond.'
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> right_range(d)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'def right_range(d):\n   if d < 0:\n      raise ValueError("The value of d seems to be negative")\n   elif d > 94:\n      raise ValueError("The value of d seems to be greater than 94")\n   else:\n      return True',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
