test = {
  'name': 'question 1ii',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q1iia_answer
          [('a', True), ('b', True), ('c', True), ('d', True), ('e', False), ('f', False), ('g', True), ('h', True), ('i', True), ('j', False), ('k', True), ('l', True), ('m', True), ('n', True), ('o', True), ('p', True), ('q', False), ('r', True), ('s', True), ('t', True), ('u', True), ('v', False), ('w', True), ('x', False), ('y', True), ('z', False)]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> q1iib_answer
          [1, 2, 4, 8, 16, 32, 64, 33, 66, 37, 74, 53, 11, 22, 44, 88, 81, 67, 39, 78, 61, 27, 54, 13, 26, 52, 9, 18, 36, 72, 49, 3, 6, 12, 24, 48, 1, 2, 4, 8, 16, 32, 64, 33, 66, 37, 74, 53, 11, 22, 44, 88, 81, 67, 39, 78, 61, 27, 54, 13, 26, 52, 9, 18, 36, 72, 49, 3, 6, 12, 24, 48, 1, 2, 4, 8, 16, 32, 64, 33, 66, 37, 74, 53, 11, 22, 44, 88, 81, 67, 39, 78, 61, 27, 54]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> q1iic_answer
          [(0, False), (1, True), (2, True), (3, True), (4, True), (5, False), (6, True), (7, False), (8, True), (9, True), (10, False), (11, True), (12, True), (13, True), (14, False), (15, False), (16, True), (17, False), (18, True), (19, False), (20, False), (21, False), (22, True), (23, False), (24, True), (25, False), (26, True), (27, True), (28, False), (29, False), (30, False), (31, False), (32, True), (33, True), (34, False), (35, False), (36, True), (37, True), (38, False), (39, True), (40, False), (41, False), (42, False), (43, False), (44, True), (45, False), (46, False), (47, False), (48, True), (49, True), (50, False), (51, False), (52, True), (53, True), (54, True), (55, False), (56, False), (57, False), (58, False), (59, False), (60, False), (61, True), (62, False), (63, False), (64, True), (65, False), (66, True), (67, True), (68, False), (69, False), (70, False), (71, False), (72, True), (73, False), (74, True), (75, False), (76, False), (77, False), (78, True), (79, False), (80, False), (81, True), (82, False), (83, False), (84, False), (85, False), (86, False), (87, False), (88, True), (89, False), (90, False), (91, False), (92, False), (93, False), (94, False)]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
