test = {
  'name': 'question 3a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> [p, q]
          [6, 9]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(x, 3.0)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
