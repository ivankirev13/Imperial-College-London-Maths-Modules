test = {
  'name': 'question 1ii',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q1iia_answer
          1237
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> q1iib_answer
          1157
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> q1iic_answer
          636
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'import numpy as np',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> q1iid_answer
          976
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> myisclose(duration, 0.0)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose\ndef myisclose(val1, val2):\n   return_value = isclose(val1, val2)\n   if not return_value:\n      raise ValueError("The powers example seems to be taking too long; did you use pow with three arguments?")\n   else:\n      return True',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
