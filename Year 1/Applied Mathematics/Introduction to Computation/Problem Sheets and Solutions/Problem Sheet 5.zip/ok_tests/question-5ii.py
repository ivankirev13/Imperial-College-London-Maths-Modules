test = {
  'name': 'question 5ii',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(q5iia_answer,(-1.5707963267948966+1.3169578969248166j))
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(q5iib_answer,(3.141592653589793-1.3169578969248166j))
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(q5iic_answer,(-0.5493061443340549+1.5707963267948966j))
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(q5iid_answer,(0.6931471805599453+3.141592653589793j))
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> myisinstance(log, ufunc)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import ufunc\ndef myisinstance(func, type):\n   if isinstance(func, type):\n      return True\n   else:\n      raise TypeError("The logarithm function does not seem to come from the numpy module")',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
