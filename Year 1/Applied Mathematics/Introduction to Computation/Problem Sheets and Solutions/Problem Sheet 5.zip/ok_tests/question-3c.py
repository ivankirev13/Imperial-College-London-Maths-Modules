test = {
  'name': 'question 3a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> [p, q]
          [6, 4]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(x, 2.7320508075688776)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
