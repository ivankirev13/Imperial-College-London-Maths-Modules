test = {
  'name': 'question 4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> iscorrect(q4_answer)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'def iscorrect(n):\n   return n == 2',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
