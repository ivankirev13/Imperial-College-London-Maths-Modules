test = {
  'name': 'question 4d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> [fibonacci_recpair(n) for n in range(2, 11)]
          [(1, 1), (1, 2), (2, 3), (3, 5), (5, 8), (8, 13), (13, 21), (21, 34), (34, 55)]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
