test = {
  'name': 'question 4c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question4c_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
