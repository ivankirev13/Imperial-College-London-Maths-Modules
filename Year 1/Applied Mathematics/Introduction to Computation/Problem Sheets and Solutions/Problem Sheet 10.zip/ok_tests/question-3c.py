test = {
  'name': 'question 3c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> [power_of_two_divisor2(a) for a in [19, 20, 22, 24, 2**31*(2**64-1)]]
          [0, 2, 1, 3, 31]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
