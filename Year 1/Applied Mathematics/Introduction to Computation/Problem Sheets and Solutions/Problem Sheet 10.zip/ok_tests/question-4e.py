test = {
  'name': 'question 4e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> [fibonacci3(n) for n in range(1, 11)]
          [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> question4e_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
