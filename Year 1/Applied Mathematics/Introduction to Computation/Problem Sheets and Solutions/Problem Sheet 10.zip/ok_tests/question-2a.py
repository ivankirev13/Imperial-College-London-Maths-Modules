test = {
  'name': 'question 2a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> pop_min_a(this_list)
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'this_list = [3, 5, 2, 7, 1, 2, 3, 1, 9]',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> this_list
          [3, 5, 2, 7, 2, 3, 1, 9]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'this_list = [3, 5, 2, 7, 1, 2, 3, 1, 9]\npm = pop_min_a(this_list)',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
