test = {
  'name': 'question 1b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> integer_digits_b(347,10)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(number=347,base=10)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(base=10,number=347)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(347)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(number=347)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> integer_digits_b(347,2)
          [1, 0, 1, 0, 1, 1, 0, 1, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(number=347,base=2)
          [1, 0, 1, 0, 1, 1, 0, 1, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(base=2,number=347)
          [1, 0, 1, 0, 1, 1, 0, 1, 1]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> integer_digits_b(239, 7)
          [4, 6, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(number=239, base=7)
          [4, 6, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(base=7, number=239)
          [4, 6, 1]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> integer_digits_b(17379, 27)
          [23, 22, 18]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(number=17379, base=27)
          [23, 22, 18]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_b(base=27, number=17379)
          [23, 22, 18]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
