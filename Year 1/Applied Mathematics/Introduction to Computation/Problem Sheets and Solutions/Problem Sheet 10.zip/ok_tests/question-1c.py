test = {
  'name': 'question 1c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> test_integer_digits_c(347,10)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(number=347,base=10)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(base=10,number=347)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(347)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(number=347)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'def test_integer_digits_c(number,base):\n   try:\n      integer_digits_c(number,base)\n   except TypeError:\n      return True\n   raise TypeError("Your function is still working for things like integer_digits(347, 10); try to make it so it no longer works in this case.")',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> test_integer_digits_c(347,2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(number=347,base=2)
          [1, 0, 1, 0, 1, 1, 0, 1, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(base=2,number=347)
          [1, 0, 1, 0, 1, 1, 0, 1, 1]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'def test_integer_digits_c(number,base):\n   try:\n      integer_digits_c(number,base)\n   except TypeError:\n      return True\n   raise TypeError("Your function is still working for things like integer_digits(347, 2); try to make it so it no longer works in this case.")',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> test_integer_digits_c(239, 7)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(number=239, base=7)
          [4, 6, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(base=7, number=239)
          [4, 6, 1]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'def test_integer_digits_c(number,base):\n   try:\n      integer_digits_c(number,base)\n   except TypeError:\n      return True\n   raise TypeError("Your function is still working for things like integer_digits(239, 7); try to make it so it no longer works in this case.")',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> test_integer_digits_c(17379, 27)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(number=17379, base=27)
          [23, 22, 18]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_c(base=27, number=17379)
          [23, 22, 18]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'def test_integer_digits_c(number,base):\n   try:\n      integer_digits_c(number,base)\n   except TypeError:\n      return True\n   raise TypeError("Your function is still working for things like integer_digits(17379, 27); try to make it so it no longer works in this case.")',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
