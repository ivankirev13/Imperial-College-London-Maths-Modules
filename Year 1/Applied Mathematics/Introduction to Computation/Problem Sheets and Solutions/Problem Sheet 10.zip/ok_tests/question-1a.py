test = {
  'name': 'question 1a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> integer_digits_a(347,10)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_a(number=347,base=10)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_a(base=10,number=347)
          [3, 4, 7]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> integer_digits_a(347,2)
          [1, 0, 1, 0, 1, 1, 0, 1, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_a(number=347,base=2)
          [1, 0, 1, 0, 1, 1, 0, 1, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_a(base=2,number=347)
          [1, 0, 1, 0, 1, 1, 0, 1, 1]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> integer_digits_a(239, 7)
          [4, 6, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_a(number=239, base=7)
          [4, 6, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_a(base=7, number=239)
          [4, 6, 1]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> integer_digits_a(17379, 27)
          [23, 22, 18]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_a(number=17379, base=27)
          [23, 22, 18]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> integer_digits_a(base=27, number=17379)
          [23, 22, 18]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
