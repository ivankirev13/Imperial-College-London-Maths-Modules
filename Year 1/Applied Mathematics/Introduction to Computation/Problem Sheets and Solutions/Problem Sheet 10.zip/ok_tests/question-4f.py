test = {
  'name': 'question 4f',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> aliquot_chain4(24)
          [24, 36, 55, 17, 1, 0, 0]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> aliquot_chain4(28)
          [28, 28]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
	{
      'cases': [
        {
          'code': r"""
          >>> aliquot_chain4(220)
          [220, 284, 220]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
