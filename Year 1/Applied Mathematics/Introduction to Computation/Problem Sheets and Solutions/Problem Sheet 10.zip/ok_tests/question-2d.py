test = {
  'name': 'question 2d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> pm
          1
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> this_list
          [3, 5, 2, 7, 2, 3, 1, 9]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> comparison_count
          18
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """this_list = [3, 5, 2, 7, 1, 2, 3, 1, 9]
pm = pop_min_d(this_list)
	  """,
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> ss
          [1, 1, 2, 2, 3, 3, 5, 7, 9]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> this_list
          [1, 1, 2, 2, 3, 3, 5, 7, 9]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> comparison_count
          117
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """this_list = [3, 5, 2, 7, 1, 2, 3, 1, 9]
ss = simple_sort(this_list)
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
