test = {
  'name': 'question 2b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> simple_sort_b(this_list)
          [1, 1, 2, 2, 3, 3, 5, 7, 9]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'this_list = [3, 5, 2, 7, 1, 2, 3, 1, 9]',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
