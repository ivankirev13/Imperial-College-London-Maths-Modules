test = {
  'name': 'question 2iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2iib_answer == {1,2,3,4,6,9}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
