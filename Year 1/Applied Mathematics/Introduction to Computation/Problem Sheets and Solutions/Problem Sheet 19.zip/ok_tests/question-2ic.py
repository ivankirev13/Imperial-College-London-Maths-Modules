test = {
  'name': 'question 2ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> ev_dict == {'mercury': 4300.0, 'venus': 10000.0, 'earth': 11000.0, 'mars': 5000.0, 'jupiter': 60000.0, 'saturn': 36000.0, 'uranus': 22000.0, 'neptune': 24000.0}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
