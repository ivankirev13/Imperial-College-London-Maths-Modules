test = {
  'name': 'question 1ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list2
          [13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 67, 69, 71, 73, 75, 77, 79, 81, 83, 85, 87, 89, 91, 93, 95, 97, 99, 101, 103]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list3
          [13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 67, 69, 71, 73, 75, 77, 79, 81, 83, 85, 87, 89, 91, 93, 95, 97, 99, 101, 103]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list2 is list1
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list3 is list1
          False
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
