test = {
  'name': 'question 4f',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> Rational(1,6).plus(Rational(1,3)).numden == (1, 2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(-1,6).plus(Rational(1,3)).numden == (1, 6)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(1,1).plus(Rational(-1,3)).numden == (2, 3)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(2,3).plus(Rational(-3,4)).numden == (-1, 12)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
