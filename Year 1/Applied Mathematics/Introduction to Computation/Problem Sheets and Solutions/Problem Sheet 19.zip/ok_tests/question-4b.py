test = {
  'name': 'question 4b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q1.numden == (1, 2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q1.num() == 1
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q1.den() == 2
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q2.numden == (2, 4)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q2.num() == 2
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q2.den() == 4
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q3.numden == (3, -6)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q3.num() == 3
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> q3.den() == -6
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
