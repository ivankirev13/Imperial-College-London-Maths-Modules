test = {
  'name': 'question 4c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> Rational(1,2).numden == (1, 2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(1,2).num() == 1
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(1,2).den() == 2
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(2,4).numden == (1, 2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(2,4).num() == 1
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(2,4).den() == 2
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(3,-9).numden == (-1, 3)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(-3,9).num() == -1
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(-3,9).den() == 3
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
