test = {
  'name': 'question 2ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> radius_list == [2400000.0, 6100000.0, 6300000.0, 3400000.0, 69000000.0, 57000000.0, 25000000.0, 25000000.0]
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
