test = {
  'name': 'question 1iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list_of_lists1
          [[1, 3, 5], [1, 4, 7], [1, 5, 9]]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_of_lists2
          [[1, 3, 5], [1, 4, 7], [1, 5, 9]]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_of_lists3
          [[1, 3, 5], [1, 4, 7], [1, 5, 9]]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_of_lists2 is list_of_lists1
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_of_lists3 is list_of_lists1
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_of_lists3[0] is list_of_lists1[0]
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
