test = {
  'name': 'question 3',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> power_set({}) == {frozenset([])}
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> power_set({0}) == {frozenset(), frozenset({0})}
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> power_set({0,1}) == {frozenset(), frozenset({1}), frozenset({0}), frozenset({0, 1})}
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> power_set({'a','b'}) == {frozenset(), frozenset({'a'}), frozenset({'b'}), frozenset({'a', 'b'})}
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> power_set({'a','b','c'}) == {frozenset(), frozenset({'a'}), frozenset({'a', 'b'}), frozenset({'c'}), frozenset({'a', 'c'}), frozenset({'b'}), frozenset({'b', 'c'}), frozenset({'a', 'b', 'c'})}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
