test = {
  'name': 'question 2id',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> combined_dict == {'mercury': 86234.86612901934, 'venus': 89625.8159530272, 'earth': 88718.18844986665, 'mars': 86772.18312746247, 'jupiter': 87458.29463880036, 'saturn': 87067.10110770876, 'uranus': 84794.35502808013, 'neptune': 83333.33333333333}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
