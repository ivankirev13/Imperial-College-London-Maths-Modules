test = {
  'name': 'question 4e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> Rational(1,2).negative().numden == (-1, 2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(3,-9).negative().numden == (1, 3)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(1,2).reciprocal().numden == (2, 1)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> Rational(3,-9).reciprocal().numden == (-3, 1)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
