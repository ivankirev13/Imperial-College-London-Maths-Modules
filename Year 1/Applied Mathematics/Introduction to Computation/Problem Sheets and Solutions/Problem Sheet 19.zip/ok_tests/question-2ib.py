test = {
  'name': 'question 2ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> name_set == {'uranus', 'saturn', 'jupiter', 'earth', 'mercury', 'mars', 'venus', 'neptune'}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
