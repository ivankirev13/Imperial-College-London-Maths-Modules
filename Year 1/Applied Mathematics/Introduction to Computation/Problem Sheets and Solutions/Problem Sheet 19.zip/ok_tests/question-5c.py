test = {
  'name': 'question 5c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> xylene_isomers_string2 == "{(1, 2): 'orthoxylene', (1, 3): 'metaxylene', (1, 4): 'paraxylene'}"
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
