test = {
  'name': 'question 5d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> xylene_isomers2 == {(1, 2): 'orthoxylene', (1, 3): 'metaxylene', (1, 4): 'paraxylene'}
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
