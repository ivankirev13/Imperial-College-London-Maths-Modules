test = {
  'name': 'question 5g',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(pickled_cos(pi/3), 0.5)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(pickled_cos(pi/6), 0.8660254037844387)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(pickled_cos(pi/4), 0.7071067811865476)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from math import pi\nfrom numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
