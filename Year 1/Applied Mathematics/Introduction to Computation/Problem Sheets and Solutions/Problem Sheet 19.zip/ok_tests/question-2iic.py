test = {
  'name': 'question 2iic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2iic_answer == set(range(1,11))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
