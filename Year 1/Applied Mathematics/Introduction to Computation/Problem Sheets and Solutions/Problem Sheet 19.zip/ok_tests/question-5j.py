test = {
  'name': 'question 5j',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> PickledRational(1,6).plus(PickledRational(1,3)).numden == (1, 2)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> PickledRational(-1,6).plus(PickledRational(1,3)).numden == (1, 6)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> PickledRational(1,1).plus(PickledRational(-1,3)).numden == (2, 3)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> PickledRational(2,3).plus(PickledRational(-3,4)).numden == (-1, 12)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
