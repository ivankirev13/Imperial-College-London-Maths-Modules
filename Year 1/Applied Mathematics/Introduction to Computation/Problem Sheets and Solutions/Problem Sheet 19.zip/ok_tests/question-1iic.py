test = {
  'name': 'question 1iic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list_of_lists1
          [[1, 3, 5], [1, 4, 7], [1, 5, 9]]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_of_lists4
          [[1, 3, 5], [1, 4, 7], [1, 5, 9]]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list_of_lists4 is list_of_lists1
          False
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> [list_of_lists4[r] is list_of_lists1[r] for r in range(3)]
          [False, False, False]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
