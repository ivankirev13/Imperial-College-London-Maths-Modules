test = {
 'name': 'question 2c',
 'points': 1,
 'suites': [
  {
   'cases': [
    {
     'code': r"""
     >>> allclose(bincoef, array([1, 10, 45, 120, 210, 252, 210, 120, 45, 10, 1]))
     True
     """,
     'hidden': False,
     'locked': False
    },
    {
     'code': r"""
     >>> allclose(binprob, array([array([2.82475249e-02, 1.21060821e-01, 2.33474440e-01, 2.66827932e-01, 2.00120949e-01, 1.02919345e-01, 3.67569090e-02, 9.00169200e-03, 1.44670050e-03, 1.37781000e-04, 5.90490000e-06])]))
     True
     """,
     'hidden': False,
     'locked': False
    }
   ],
   'scored': True,
   'setup': 'from numpy import array, allclose, flip',
   'teardown': '',
   'type': 'doctest'
  },
  {
   'cases': [
    {
     'code': r"""
     >>> isinstance(bincoef, ndarray)
     True
     """,
     'hidden': False,
     'locked': False
    },
    {
     'code': r"""
     >>> isinstance(binprob, ndarray)
     True
     """,
     'hidden': False,
     'locked': False
    }
   ],
   'scored': True,
   'setup': 'from numpy import ndarray',
   'teardown': '',
   'type': 'doctest'
  },
  {
   'cases': [
    {
     'code': r"""
     >>> shape(bincoef)
     (11,)
     """,
     'hidden': False,
     'locked': False
    },
    {
     'code': r"""
     >>> shape(binprob)
     (11,)
     """,
     'hidden': False,
     'locked': False
    }
   ],
   'scored': True,
   'setup': 'from numpy import shape',
   'teardown': '',
   'type': 'doctest'
  }
 ]
}
