test = {
  'name': 'question 3c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(x_values0, linspace(-2.0, 2.0, 40))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(y_values0, linspace(-2.0, 2.0, 40))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(x0, linspace(-2.0, 2.0, 40))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(transpose(y0), linspace(-2.0, 2.0, 40))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(z0, x0+1j*y0)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import linspace, allclose, transpose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(x_values0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(y_values0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(x0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(y0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(z0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import ndarray',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> shape(x_values0)
          (40,)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(y_values0)
          (40,)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(x0)
          (40, 40)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(y0)
          (40, 40)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(z0)
          (40, 40)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import shape',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
