test = {
  'name': 'question 3d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(roots, newton_numpy_instructor(lambda z: z**3-1, lambda z: 3*z**2, z0, 100))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'def newton_numpy_instructor(func, dfunc, x0, niterate):\n    # initialize\n    x = x0\n    # loop and return\n    for n in range(niterate):\n        x = x - func(x)/dfunc(x)\n    return x\nfrom numpy import allclose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(roots, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import ndarray',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> shape(roots)
          (40, 40)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import shape',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
