test = {
  'name': 'question 1e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question1e_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
