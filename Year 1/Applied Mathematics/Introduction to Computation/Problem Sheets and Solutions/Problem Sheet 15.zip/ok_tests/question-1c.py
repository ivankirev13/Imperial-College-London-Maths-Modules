test = {
  'name': 'question 1c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(x_values2, linspace(-1.2, 1.2, 121))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(y_values2, linspace(-1.2, 1.2, 121))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(x2, linspace(-1.2, 1.2, 121))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(transpose(y2), linspace(-1.2, 1.2, 121))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import linspace, allclose, transpose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(x_values2, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(y_values2, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(x2, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(y2, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import ndarray',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> shape(x_values2)
          (121,)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(y_values2)
          (121,)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(x2)
          (121, 121)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(y2)
          (121, 121)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import shape',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
