test = {
  'name': 'question 2a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(r, arange(11))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import arange, allclose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(r, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import ndarray',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> shape(r)
          (11,)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import shape',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
