test = {
 'name': 'question 2b',
 'points': 1,
 'suites': [
  {
   'cases': [
    {
     'code': r"""
     >>> allclose(rfac, array([1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800]))
     True
     """,
     'hidden': False,
     'locked': False
    },
    {
     'code': r"""
     >>> allclose(flip(nmrfac), array([1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800]))
     True
     """,
     'hidden': False,
     'locked': False
    }
   ],
   'scored': True,
   'setup': 'from numpy import array, allclose, flip',
   'teardown': '',
   'type': 'doctest'
  },
  {
   'cases': [
    {
     'code': r"""
     >>> isinstance(rfac, ndarray)
     True
     """,
     'hidden': False,
     'locked': False
    },
    {
     'code': r"""
     >>> isinstance(nmrfac, ndarray)
     True
     """,
     'hidden': False,
     'locked': False
    }
   ],
   'scored': True,
   'setup': 'from numpy import ndarray',
   'teardown': '',
   'type': 'doctest'
  },
  {
   'cases': [
    {
     'code': r"""
     >>> shape(rfac)
     (11,)
     """,
     'hidden': False,
     'locked': False
    },
    {
     'code': r"""
     >>> shape(nmrfac)
     (11,)
     """,
     'hidden': False,
     'locked': False
    }
   ],
   'scored': True,
   'setup': 'from numpy import shape',
   'teardown': '',
   'type': 'doctest'
  }
 ]
}
