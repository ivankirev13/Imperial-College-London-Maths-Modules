test = {
  'name': 'question 1a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(x_values1, linspace(-1.2, 1.2, 25))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(y_values1, linspace(-1.2, 1.2, 25))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(x1, linspace(-1.2, 1.2, 25))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(transpose(y1), linspace(-1.2, 1.2, 25))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import linspace, allclose, transpose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(x_values1, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(y_values1, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(x1, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(y1, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import ndarray',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> shape(x_values1)
          (25,)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(y_values1)
          (25,)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(x1)
          (25, 25)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(y1)
          (25, 25)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import shape',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
