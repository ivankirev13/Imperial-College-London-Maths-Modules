test = {
  'name': 'question 3a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(newton_numpy(lambda x: x-cos(x), lambda x: 1+sin(x), 1.0, 5), 0.7390851332151607)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(newton_numpy(lambda z: z**3-1, lambda z: 3*z**2, array([2.0,-1+1j,-1-1j]), 5), array([1.00000001+0.j, -0.5+0.8660254j, -0.5-0.8660254j]))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import isclose, allclose, array, cos, sin',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
