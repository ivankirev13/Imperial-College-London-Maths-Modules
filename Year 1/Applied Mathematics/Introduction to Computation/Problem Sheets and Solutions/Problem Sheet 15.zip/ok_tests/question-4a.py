test = {
  'name': 'question 4a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> set([tuple(ifs_step(mats,vecs,array([0.5,0.5]))) for i in range(100)]).issubset({(0.16666666666666666, 0.16666666666666666), (0.27232909936926025, 0.2276709006307398), (0.7276709006307398, 0.2276709006307398), (0.8333333333333333, 0.16666666666666666)})
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import array, cos, sin, pi, sqrt \nmat0=array([[1.0,0.0],[0.0,1.0]])/3\nmat1=array([[cos(pi/3),-sin(pi/3)],[sin(pi/3),cos(pi/3)]])/3\nmat2 = array([[cos(-pi/3),-sin(-pi/3)],[sin(-pi/3),cos(-pi/3)]])/3\nmat3 = array([[1.0,0.0],[0.0,1.0]])/3\nmats = array([mat0,mat1,mat2,mat3])\nvec0 = array([0.0,0.0])\nvec1 = array([1.0/3,0.0])\nvec2 = array([0.5,sqrt(3)/6])\nvec3 = array([2.0/3,0.0])\nvecs = array([vec0,vec1,vec2,vec3])',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
