test = {
  'name': 'question 6c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(mypoly_roots, array([ 9., -5.,  3.,  1.]))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import array, allclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
