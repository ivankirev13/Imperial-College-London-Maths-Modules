test = {
  'name': 'question 1iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question1iib_answer
          4
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
