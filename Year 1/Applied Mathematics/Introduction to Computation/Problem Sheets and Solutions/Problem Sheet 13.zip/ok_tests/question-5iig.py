test = {
  'name': 'question 5iig',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(eigvalsA,array([3.02385899,-2.28250615,-0.42429781,0.68294497]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(eigvalsA,ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> ndim(eigvalsA)
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import allclose, array, ndarray, ndim',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
