test = {
  'name': 'question 5iij',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(linear_solution,array([-1.,1., -1.,3.]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(linear_solution,ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> ndim(linear_solution)
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import allclose, array, ndarray, ndim',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
