test = {
  'name': 'question 5iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(normv,5.477225575051661)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
