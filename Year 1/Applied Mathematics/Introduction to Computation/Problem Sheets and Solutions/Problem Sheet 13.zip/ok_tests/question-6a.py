test = {
  'name': 'question 6a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> mypoly == poly1d([1, -8, -26, 168, -135])
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import poly1d',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
