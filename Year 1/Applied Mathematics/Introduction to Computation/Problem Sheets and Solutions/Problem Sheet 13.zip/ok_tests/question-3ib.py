test = {
  'name': 'question 3ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question3ib_answer
          3
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
