test = {
  'name': 'question 1ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question1ia_answer
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
