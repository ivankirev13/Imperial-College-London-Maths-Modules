test = {
  'name': 'question 5iih',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(matrix_powerA5,array([[13,-12,22,41],[34,31,47,-31],[130,99,183,-75],[-109,-39,-161,-36]]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(matrix_powerA5,ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> ndim(matrix_powerA5)
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import allclose, array, ndarray, ndim',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
