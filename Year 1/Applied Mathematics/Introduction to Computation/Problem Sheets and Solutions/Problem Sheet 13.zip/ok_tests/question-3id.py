test = {
  'name': 'question 3id',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question3id_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
