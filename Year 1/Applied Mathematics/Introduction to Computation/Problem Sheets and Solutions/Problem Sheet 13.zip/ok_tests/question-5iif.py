test = {
  'name': 'question 5iif',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(invA,array([[ 0.5,-9.0,3.5,1.5],[-0.5,1.0,-0.5,-0.5],[0.0,6.0,-2.0,-1.0],[-0.5,0.0,-0.5,-0.5]]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(invA,ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import allclose, array, ndarray',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
