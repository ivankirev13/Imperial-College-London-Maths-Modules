test = {
  'name': 'question 3iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question3iib_answer
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
