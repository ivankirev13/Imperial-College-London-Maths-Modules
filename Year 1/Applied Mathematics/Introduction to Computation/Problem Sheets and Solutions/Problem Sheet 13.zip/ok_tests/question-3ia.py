test = {
  'name': 'question 3ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question3ia_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
