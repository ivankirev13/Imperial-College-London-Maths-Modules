test = {
  'name': 'question 2iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2iib_answer
          3
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
