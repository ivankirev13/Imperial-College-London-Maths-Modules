test = {
  'name': 'question 5id',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question5id_answer
          4
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
