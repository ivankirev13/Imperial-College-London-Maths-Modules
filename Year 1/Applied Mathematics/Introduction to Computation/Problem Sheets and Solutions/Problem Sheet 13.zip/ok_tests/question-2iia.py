test = {
  'name': 'question 2iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2iia_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
