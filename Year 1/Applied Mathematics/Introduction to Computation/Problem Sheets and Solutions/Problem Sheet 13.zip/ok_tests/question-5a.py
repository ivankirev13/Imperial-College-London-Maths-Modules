test = {
  'name': 'question 5a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> vectors
          np.array([[0.0,0.0],[0.0,1.6],[0.0, 1.6],[0.0,0.44]])
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'import numpy as np',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
