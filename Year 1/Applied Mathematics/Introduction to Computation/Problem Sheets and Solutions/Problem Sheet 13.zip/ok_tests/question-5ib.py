test = {
  'name': 'question 5ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question5ib_answer
          {1, 2, 4}
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
