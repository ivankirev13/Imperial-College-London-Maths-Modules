test = {
  'name': 'question 4a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question4a_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
