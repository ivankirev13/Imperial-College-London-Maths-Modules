test = {
  'name': 'question 6b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> all(mypoly_values == array([ 945,    0, -455, -576, -495, -320, -135,    0,   49,    0, -135, -320, -495, -576, -455,    0,  945]))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import array',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
