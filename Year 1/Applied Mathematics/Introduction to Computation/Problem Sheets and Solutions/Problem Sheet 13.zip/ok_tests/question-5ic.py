test = {
  'name': 'question 5ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question5ic_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'import numpy as np',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
