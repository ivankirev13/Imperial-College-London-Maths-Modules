test = {
  'name': 'question 5iik',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(linear_solution2,array([1.,-3.,2.,1.]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(linear_solution2,ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> ndim(linear_solution2)
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import allclose, array, ndarray, ndim',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
