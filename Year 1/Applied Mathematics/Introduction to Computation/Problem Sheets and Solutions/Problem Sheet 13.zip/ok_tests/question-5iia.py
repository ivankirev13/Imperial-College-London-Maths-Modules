test = {
  'name': 'question 5iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(matA,array([[1,-3,2,2],[0,1,0,-1],[1,3,1,-2],[-2,0,-3,-2]]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(vecv,array([0,-2,-5,-1]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(matA,ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(vecv,ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> ndim(matA)
          2
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> ndim(vecv)
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import allclose, array, ndarray, ndim',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
