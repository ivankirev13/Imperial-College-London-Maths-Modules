test = {
  'name': 'question 6d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(mypoly_sp_x, array([ 7., -3.,  2.]))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(mypoly_sp_y, array([-576., -576.,   49.]))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import array, allclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
