test = {
  'name': 'question 2ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2ib_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
