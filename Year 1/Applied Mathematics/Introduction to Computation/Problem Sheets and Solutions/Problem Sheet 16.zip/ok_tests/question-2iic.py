test = {
  'name': 'question 2iic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> from_continued_fraction([3, 7, 15, 1, 292, 1, 1, 1, 2, 1])
          1146408/364913
          """,
          'hidden': False,
          'locked': False
        },
		{
          'code': r"""
          >>> from_continued_fraction([1, 2, 2, 2, 2, 2, 2, 2, 2, 2])
          3363/2378
          """,
          'hidden': False,
          'locked': False
        },
		{
          'code': r"""
          >>> from_continued_fraction([1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
          89/55
          """,
          'hidden': False,
          'locked': False
        },
		{
          'code': r"""
          >>> from_continued_fraction([3, 7])
          22/7
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
