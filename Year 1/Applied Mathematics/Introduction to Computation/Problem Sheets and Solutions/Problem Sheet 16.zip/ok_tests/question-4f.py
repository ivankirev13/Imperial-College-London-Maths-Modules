test = {
  'name': 'question 4e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(x_values0, linspace(-2.0, 2.0, 400))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(y_values0, linspace(-2.0, 2.0, 400))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(x0, linspace(-2.0, 2.0, 400))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(transpose(y0), linspace(-2.0, 2.0, 400))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(z0, x0+1j*y0)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(roots**3, 1)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import allclose, array, linspace, transpose',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> isinstance(x_values0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(y_values0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(x0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(y0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(z0, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(roots, ndarray)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import ndarray',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> shape(x_values0)
          (400,)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(y_values0)
          (400,)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(x0)
          (400, 400)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(y0)
          (400, 400)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(z0)
          (400, 400)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> shape(roots)
          (400, 400)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import shape',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
