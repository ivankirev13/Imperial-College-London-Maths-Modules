test = {
  'name': 'question 3j',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> dydx
          4*x**3 - 24*x**2 + 52*x - 40
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> x_stat
          [2, 2 - I, 2 + I]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> x_stat_real
          [2]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> y_stat_real
          [-3]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
