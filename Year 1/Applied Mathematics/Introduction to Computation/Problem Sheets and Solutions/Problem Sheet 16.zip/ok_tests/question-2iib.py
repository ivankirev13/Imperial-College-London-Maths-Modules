test = {
  'name': 'question 2iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q2iib_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
