test = {
  'name': 'question 4e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(roots, array([ 1. +0.j       , -0.5+0.8660254j, -0.5-0.8660254j]))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import allclose, array',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
