test = {
  'name': 'question 2ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q2id_answer
          3
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
