test = {
  'name': 'question 2ie',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (p, q, x)
          (3, 18, 3)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> (isinstance(p, Integer), isinstance(q, Integer), isinstance(x, Integer))
          (True, True, True)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from sympy.core.numbers import Integer',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
