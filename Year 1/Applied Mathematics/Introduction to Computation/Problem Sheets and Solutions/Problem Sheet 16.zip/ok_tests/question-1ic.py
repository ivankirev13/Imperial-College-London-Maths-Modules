test = {
  'name': 'question 1ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> expr2
          x**4 - 5*x**3 + 7*x**2 + 3*x - 10
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(expr2, Add)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from sympy.core.add import Add',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
