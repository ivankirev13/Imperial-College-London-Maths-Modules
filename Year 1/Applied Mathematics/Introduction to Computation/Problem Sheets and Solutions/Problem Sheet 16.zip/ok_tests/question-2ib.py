test = {
  'name': 'question 2ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (p, q, x)
          (3, 18, (-4*sqrt(5) + 9)**(1/3) + (4*sqrt(5) + 9)**(1/3))
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> (isinstance(p, Integer), isinstance(q, Integer))
          (True, True)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from sympy.core.numbers import Integer',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
