test = {
  'name': 'question 1id',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> expr2_zeros
          [-1, 2, 2 - I, 2 + I]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
