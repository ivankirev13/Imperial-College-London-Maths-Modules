test = {
  'name': 'question 1ie',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> int_expr
          816/5
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(int_expr, Rational)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from sympy.core.numbers import Rational',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
