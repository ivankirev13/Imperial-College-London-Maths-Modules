test = {
  'name': 'question 4b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(float(sqrt2_frac), 1.4142135623730951)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(sqrt2_frac, Rational)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """from numpy import isclose\nfrom sympy.core.numbers import Rational""",
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
