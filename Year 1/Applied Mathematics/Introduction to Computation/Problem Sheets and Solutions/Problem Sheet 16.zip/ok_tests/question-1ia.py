test = {
  'name': 'question 1ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> x
          x
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> t
          t
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(x, Symbol)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(t, Symbol)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from sympy.core.symbol import Symbol',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
