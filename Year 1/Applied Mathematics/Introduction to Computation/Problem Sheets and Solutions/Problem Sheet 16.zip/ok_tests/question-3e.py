test = {
  'name': 'question 3e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> y_zeros_real
          [1, 3]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
