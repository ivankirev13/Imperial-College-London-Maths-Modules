test = {
  'name': 'question 1if',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> f
          f(t)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> fexpr
          f(t)**4 - 5*f(t)**3 + 7*f(t)**2 + 3*f(t) - 10
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
