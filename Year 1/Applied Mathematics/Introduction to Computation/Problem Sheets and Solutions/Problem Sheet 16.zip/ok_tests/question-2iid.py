test = {
  'name': 'question 2iid',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> rational_sequence(pi, 5)
          [3, 22/7, 333/106, 355/113, 103993/33102]
          """,
          'hidden': False,
          'locked': False
        },
		{
          'code': r"""
          >>> rational_sequence(sqrt(2), 5)
          [1, 3/2, 7/5, 17/12, 41/29]
          """,
          'hidden': False,
          'locked': False
        },
		{
          'code': r"""
          >>> rational_sequence((1+sqrt(5))/2, 5)
          [1, 2, 3/2, 5/3, 8/5]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from sympy import pi, sqrt',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
