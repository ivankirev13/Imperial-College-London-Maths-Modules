test = {
  'name': 'question 4a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(float(newton_sympy(x-cos(x), x, 1.0, 5)), 0.7390851332151607)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(newton_sympy(x-cos(x), x, 1.0, 5, method='float'), 0.7390851332151607)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(newton_sympy(z**3-1, z, -1+1j, 5, method='complex').real, -0.4999999999999554)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(newton_sympy(z**3-1, z, -1+1j, 5, method='complex').imag, 0.8660254037846932)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isclose(float(newton_sympy(x**2-2, x, 1, 6)), 1.4142135623730951)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(newton_sympy(x**2-2, x, 1, 6), Rational)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(newton_sympy(z**3 - 1, z, array([2,-1+1j,-1-1j]), 6, method='lambdify'), array([ 1. +0.j       , -0.5+0.8660254j, -0.5-0.8660254j]))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """from sympy import cos, symbols\nfrom numpy import array, isclose, allclose, sqrt\nx = symbols('x')\nz = symbols('z')\nfrom sympy.core.numbers import Rational""",
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
