test = {
  'name': 'question 1ig',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> gen_sol
          Eq(t - log(f(t) - 2)/3 + log(f(t) + 1)/30 + 3*log(f(t)**2 - 4*f(t) + 5)/20 + atan(f(t) - 2)/10, C1)
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
