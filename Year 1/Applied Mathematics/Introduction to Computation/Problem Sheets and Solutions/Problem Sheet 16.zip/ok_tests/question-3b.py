test = {
  'name': 'question 3b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> y
          x**4 - 8*x**3 + 26*x**2 - 40*x + 21
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
