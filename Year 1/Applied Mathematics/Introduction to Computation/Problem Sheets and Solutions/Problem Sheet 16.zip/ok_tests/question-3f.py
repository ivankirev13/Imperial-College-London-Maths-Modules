test = {
  'name': 'question 3f',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> yfunc(arange(-1,6))
          array([96, 21,  0, -3,  0, 21, 96])
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import arange, array',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
