test = {
  'name': 'question 2iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> pi_cf
          [3, 7, 15, 1, 292, 1, 1, 1, 2, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> sqrt2_cf
          [1, 2, 2, 2, 2, 2, 2, 2, 2, 2]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> phi_cf
          [1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> rat_cf
          [3, 7]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from sympy.core.numbers import Integer',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
