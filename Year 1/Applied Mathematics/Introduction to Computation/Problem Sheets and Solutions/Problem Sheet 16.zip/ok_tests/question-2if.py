test = {
  'name': 'question 2if',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q1f_answer
          4
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
