test = {
  'name': 'question 3d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> y_zeros
          [1, 3, 2 - sqrt(3)*I, 2 + sqrt(3)*I]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
