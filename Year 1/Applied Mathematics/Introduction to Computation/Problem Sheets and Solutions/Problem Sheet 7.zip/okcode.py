from client.api.notebook import Notebook
from client.api import assignment
from client.utils import auth

ok = Notebook('./tests.ok')
