test = {
  'name': 'question 1c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> all(isclose(xlist, [0.0, 1.0, 0.36787944117144233, 0.6922006275553464, 0.5004735005636368, 0.6062435350855974, 0.545395785975027, 0.5796123355033789, 0.5601154613610891, 0.571143115080177, 0.5648793473910495]))
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose, all',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
