test = {
  'name': 'question 4f',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q4f_answer
          3
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
