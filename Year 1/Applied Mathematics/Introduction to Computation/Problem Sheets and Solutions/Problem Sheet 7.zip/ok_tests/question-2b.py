test = {
  'name': 'question 2b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(newx, 0.5671430308342419)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
