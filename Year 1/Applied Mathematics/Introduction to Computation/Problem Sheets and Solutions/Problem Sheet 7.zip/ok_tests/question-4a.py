test = {
  'name': 'question 4a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list(myrange)
          [97, 98, 99, 100, 101, 102]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(myrange,range)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> mylist
          [97, 98, 99, 100, 101, 102]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(mylist,list)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> list(myslice)
          [97, 98, 99, 100, 101, 102]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(myslice,islice)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from itertools import islice',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
