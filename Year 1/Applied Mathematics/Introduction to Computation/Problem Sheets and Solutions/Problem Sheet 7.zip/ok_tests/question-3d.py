test = {
  'name': 'question 3d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> check_factor_sum(a, factor_sum)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'def check_factor_sum(a,fs):\n   if a==24:\n      return factor_sum == 60\n   elif a==36:\n      return factor_sum == 91\n   else:\n      raise ValueError("I can only check for a == 24 or a == 36")',
      'teardown': '',
      'type': 'doctest'
    },
	{
      'cases': [
        {
          'code': r"""
          >>> check_iteration_count(a, r)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'def check_iteration_count(a,r):\n   if a==24:\n      if r == 4:\n         return True\n      else:\n         raise ValueError("The iteration count does not seem to be right; 4 iterations should be necessary")\n   elif a==36:\n      if r == 6:\n         return True\n      else:\n         raise ValueError("The iteration count does not seem to be right; 6 iterations should be necessary")\n   else:\n      raise ValueError("I can only check for a == 24 or a == 36")',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
