test = {
  'name': 'question 3c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> factor_sum
          60
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
	{
      'cases': [
        {
          'code': r"""
          >>> check_iteration_count(r)
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': 'def check_iteration_count(r):\n   if r == 4:\n      return True\n   else:\n      raise ValueError("The iteration count does not seem to be right; 4 iterations should be necessary.")',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
