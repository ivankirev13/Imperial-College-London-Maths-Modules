test = {
  'name': 'question 2e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> a
          37
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
