test = {
  'name': 'question 2ii',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q2iia_answer
          ['one', 2, 3.0, (4+0j), 'five', 6, 7.0, (8+0j), 'nine', 10, 11.0]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> q2iib_answer
          ['one', 3.0, 'five', 7.0, 'nine', 11.0]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> q2iic_answer
          ['one', 2, 3.0, (4+0j), 'five', 6, 7.0, (8+0j), 'nine', 10, 11.0, (12+0j), 'thirteen', 14, 15.0, (16+0j), 'one', 2, 3.0, (4+0j), 'five', 6, 7.0, (8+0j), 'nine', 10, 11.0, (12+0j), 'thirteen', 14, 15.0, (16+0j), 'one', 2, 3.0, (4+0j), 'five', 6, 7.0, (8+0j), 'nine', 10, 11.0, (12+0j), 'thirteen', 14, 15.0, (16+0j)]
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
