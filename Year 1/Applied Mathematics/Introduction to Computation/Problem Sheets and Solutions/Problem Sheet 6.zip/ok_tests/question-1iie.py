test = {
  'name': 'question 1iie',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question1iie_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
