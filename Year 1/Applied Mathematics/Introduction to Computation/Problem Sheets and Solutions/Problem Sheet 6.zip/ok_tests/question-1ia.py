test = {
  'name': 'question 1ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> int1
          123
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> int2
          456
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> int3
          789
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(int1,int)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(int2,int)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(int3,int)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
