test = {
  'name': 'question 3e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> string5
          'The quick brown dog jumps over the lazy fox'
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
