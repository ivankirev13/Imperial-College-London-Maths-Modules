test = {
  'name': 'question 1ie',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question1ie_answer
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
