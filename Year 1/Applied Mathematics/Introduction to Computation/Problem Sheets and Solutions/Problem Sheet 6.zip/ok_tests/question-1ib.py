test = {
  'name': 'question 1ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> float1
          123.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> float2
          456.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> float3
          789.0
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(float1,float)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(float2,float)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(float3,float)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
