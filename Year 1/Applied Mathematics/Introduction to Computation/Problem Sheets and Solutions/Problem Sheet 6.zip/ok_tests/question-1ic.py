test = {
  'name': 'question 1ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question1ic_answer
          3
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
