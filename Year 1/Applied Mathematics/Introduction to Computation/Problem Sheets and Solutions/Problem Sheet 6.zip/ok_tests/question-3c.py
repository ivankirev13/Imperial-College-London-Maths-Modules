test = {
  'name': 'question 3c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> string3
          'brown, dog, fox, jumps, lazy, over, quick, the, the'
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
