test = {
  'name': 'question 3d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> string4
          'The quick brown fox jumps over the lazy cat'
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
