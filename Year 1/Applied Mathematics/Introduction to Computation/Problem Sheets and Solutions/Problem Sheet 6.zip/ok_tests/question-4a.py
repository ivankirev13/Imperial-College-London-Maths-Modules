test = {
  'name': 'question 4a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> polyhedron2
          'The regular solid known as the cube has 6 square faces, 12 edges and 8 vertices.'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> polyhedron3
          'The regular solid known as the octahedron has 8 triangular faces, 12 edges and 6 vertices.'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
