test = {
  'name': 'question 4b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> polyhedron_template2
          'The regular solid known as the {4} has {2} {3} faces, {1} edges and {0} vertices.'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> polyhedron_template2.format(8,12,6,'square','cube')
          'The regular solid known as the cube has 6 square faces, 12 edges and 8 vertices.'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> polyhedron_template2.format(4,6,4,'triangular','tetrahedron')
          'The regular solid known as the tetrahedron has 4 triangular faces, 6 edges and 4 vertices.'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> polyhedron_template2.format(6,12,8,'triangular','octahedron')
          'The regular solid known as the octahedron has 8 triangular faces, 12 edges and 6 vertices.'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
