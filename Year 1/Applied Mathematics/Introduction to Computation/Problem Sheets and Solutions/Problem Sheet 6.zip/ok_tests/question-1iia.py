test = {
  'name': 'question 1iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> complex1
          (123+0j)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> complex2
          (456+0j)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> complex3
          (789+0j)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> complex4
          (123+456j)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> complex5
          (123+456j)
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(complex1,complex)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(complex2,complex)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(complex3,complex)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(complex4,complex)
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(complex5,complex)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
