test = {
  'name': 'question 1id',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question1id_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
