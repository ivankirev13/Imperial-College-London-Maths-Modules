test = {
  'name': 'question 3iic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> merge_sort_length16_max
          49
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
