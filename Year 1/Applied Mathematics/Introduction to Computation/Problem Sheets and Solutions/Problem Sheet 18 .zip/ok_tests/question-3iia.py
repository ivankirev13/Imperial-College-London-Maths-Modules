test = {
  'name': 'question 3iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [3, 5, 7, 12, 17, 18, 19, 21, 22, 24, 26, 27, 29, 31, 34, 40]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'new_data=[3, 34, 12, 22, 27, 17, 31, 29, 40, 24, 21, 19, 7, 18, 26, 5]\nmerge_sort(new_data)',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
