test = {
  'name': 'question 3ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> merge_length16_max
          15
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
