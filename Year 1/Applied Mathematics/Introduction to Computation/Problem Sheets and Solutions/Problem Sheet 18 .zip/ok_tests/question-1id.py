test = {
  'name': 'question 1id',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q1id_answer
          1
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
