test = {
  'name': 'question 3iid',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> [merge_sort_min(m) for m in range(1,8)]
          [1, 4, 12, 32, 80, 192, 448]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
