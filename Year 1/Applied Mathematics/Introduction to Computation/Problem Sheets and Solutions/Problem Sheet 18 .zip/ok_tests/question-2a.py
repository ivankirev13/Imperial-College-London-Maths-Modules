test = {
  'name': 'question 2a',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> data
          [3, 4, 5, 9, 7, 2, 1, 6]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [3, 5, 9, 4, 7, 2, 1, 6]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'new_data = [3, 5, 9, 4, 7, 2, 1, 6]\ninsertion_pass(new_data,1)',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [3, 5, 9, 4, 7, 2, 1, 6]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'new_data = [3, 5, 9, 4, 7, 2, 1, 6]\ninsertion_pass(new_data,2)',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [3, 4, 5, 7, 9, 2, 1, 6]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'new_data = [3, 4, 5, 9, 7, 2, 1, 6]\ninsertion_pass(new_data,4)',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [2, 3, 4, 5, 7, 9, 1, 6]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'new_data = [3, 4, 5, 7, 9, 2, 1, 6]\ninsertion_pass(new_data,5)',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [1, 2, 3, 4, 5, 7, 9, 6]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'new_data = [2, 3, 4, 5, 7, 9, 1, 6]\ninsertion_pass(new_data,6)',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [1, 2, 3, 4, 5, 6, 7, 9]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'new_data = [1, 2, 3, 4, 5, 7, 9, 6]\ninsertion_pass(new_data,7)',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
