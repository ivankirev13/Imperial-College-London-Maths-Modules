test = {
  'name': 'question 2f',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> insertion_sort_count(insertion_sort_length16_bestcase)
          15
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
def insertion_pass_count(data, already_sorted):
    comparison_count = 0
    next_item = data[already_sorted]
    insertion_index = already_sorted-1
    comparison_count += 1
    while next_item < data[insertion_index] and insertion_index > -1:
        comparison_count += 1
        insertion_index -= 1
    if insertion_index == -1:
        comparison_count -= 1
    data[insertion_index+2:already_sorted+1] = data[insertion_index+1:already_sorted]
    data[insertion_index+1] = next_item
    return comparison_count
def insertion_sort_count(data):    
    comparison_count = 0
    for already_sorted in range(1,len(data)):
        comparison_count += insertion_pass_count(data, already_sorted)
    return comparison_count
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
