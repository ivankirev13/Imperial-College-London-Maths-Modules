test = {
  'name': 'question 3ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> merge_length16_min
          8
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
