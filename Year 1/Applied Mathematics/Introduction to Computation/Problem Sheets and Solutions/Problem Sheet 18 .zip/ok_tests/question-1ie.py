test = {
  'name': 'question 1ie',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> [bubble_sort_simple_max(n) for n in range(1,17)]
          [0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> [bubble_sort_simple_min(n) for n in range(1,17)]
          [0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
