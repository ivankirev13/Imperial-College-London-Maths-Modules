test = {
  'name': 'question 2e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> insertion_sort_length16_min
          15
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
