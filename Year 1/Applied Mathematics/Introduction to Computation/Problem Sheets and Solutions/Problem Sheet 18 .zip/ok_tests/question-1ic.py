test = {
  'name': 'question 1ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> data
          [3, 5, 7, 12, 17, 18, 19, 21, 22, 24, 26, 27, 29, 31, 34, 40]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> comparison_count
          120
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
