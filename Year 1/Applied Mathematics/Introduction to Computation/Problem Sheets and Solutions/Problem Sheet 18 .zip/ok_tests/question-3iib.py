test = {
  'name': 'question 3iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> merge_sort_length16_min
          32
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
