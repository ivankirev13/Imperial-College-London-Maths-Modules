test = {
  'name': 'question 3iic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> merge_sort_count(merge_sort_length16_worstcase)
          49
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
def merge_count(left_buffer, right_buffer, data):
    comparison_count = 0
    left_index = right_index = main_index = 0
    while left_index < len(left_buffer) and right_index < len(right_buffer):
        comparison_count += 1
        if left_buffer[left_index] < right_buffer[right_index]:
            data[main_index] = left_buffer[left_index]
            left_index += 1
        else:
            data[main_index] = right_buffer[right_index]
            right_index += 1
        main_index += 1
    if left_index < len(left_buffer):
        data[main_index:] = left_buffer[left_index]
    else:
        data[main_index:] = right_buffer[right_index:]
    return comparison_count
def merge_sort_count(data):
    comparison_count = 0
    ndata = len(data)
    if ndata > 1:
        mid = ndata//2
        left_half = data[0:mid]
        right_half = data[mid:ndata]
        comparison_count += merge_sort_count(left_half)
        comparison_count += merge_sort_count(right_half)
        comparison_count += merge_count(left_half,right_half,data)
    return comparison_count
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
