test = {
  'name': 'question 3iif',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> q3iif_answer
          2
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
