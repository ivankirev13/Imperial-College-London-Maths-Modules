test = {
  'name': 'question 2h',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> question2h_answer
          4
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
