test = {
  'name': 'question 2b',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> data
          [3, 5, 7, 12, 17, 18, 19, 21, 22, 24, 26, 27, 29, 31, 34, 40]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> data is masterData
          False
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [1, 2, 3, 4, 5, 6, 7, 9]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'new_data = [3, 5, 9, 4, 7, 2, 1, 6]\ninsertion_sort(new_data)',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
