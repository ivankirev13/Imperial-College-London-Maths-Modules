test = {
  'name': 'question 2c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> insertion_sort_length16_max
          120
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
