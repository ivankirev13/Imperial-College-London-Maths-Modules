test = {
  'name': 'question 3ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [2, 3, 5, 7, 8, 9, 10]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'left_buffer=[3,7,8]\nright_buffer=[2,5,9,10]\nnew_data=[0,0,0,0,0,0,0]\nmerge(left_buffer,right_buffer,new_data)',
      'teardown': '',
      'type': 'doctest'
    },
    {
      'cases': [
        {
          'code': r"""
          >>> new_data
          [2, 3, 5, 7, 8, 9, 10]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'left_buffer=[3,7,8]\nright_buffer=[2,5,9,10]\nnew_data=[0,0,0,0,0,0,0]\nmerge(right_buffer,left_buffer,new_data)',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
