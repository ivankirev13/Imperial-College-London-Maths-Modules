test = {
  'name': 'question 1iic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> [bubble_sort_enhanced_max(n) for n in range(1,17)]
          [0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> [bubble_sort_enhanced_min(n) for n in range(1,17)]
          [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
