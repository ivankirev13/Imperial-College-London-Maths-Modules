test = {
  'name': 'question 1ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> data
          [3, 34, 12, 22, 27, 17, 31, 29, 40, 24, 21, 19, 7, 18, 26, 5]
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> data is masterData
          False
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
