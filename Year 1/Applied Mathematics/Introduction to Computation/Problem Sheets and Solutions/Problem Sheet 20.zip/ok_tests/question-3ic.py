test = {
  'name': 'question 3ic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (stocks_df2 == my_stocks_df2).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(stocks_df2.index,core.indexes.datetimes.DatetimeIndex)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
from pandas import read_csv, to_datetime, core
my_stocks_df2 = read_csv('historical_stock_market.csv',index_col='Date')
my_stocks_df2.index = to_datetime(my_stocks_df2.index)
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
