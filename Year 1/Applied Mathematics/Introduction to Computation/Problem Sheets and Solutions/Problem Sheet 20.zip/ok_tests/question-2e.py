test = {
  'name': 'question 2e',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list(planets_df['orbital_radius']) == [58500000.0, 108000000.0, 150000000.0, 225000000.0, 780000000.0, 1425000000.0, 2850000000.0, 4500000000.0]
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}