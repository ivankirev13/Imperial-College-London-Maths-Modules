test = {
  'name': 'question 3iid',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (stocks_df_monthly2 == my_stocks_df_monthly2).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(stocks_df_monthly2.index,core.indexes.datetimes.DatetimeIndex)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
from pandas import read_csv, to_datetime, core, concat
my_stocks_df2 = read_csv('historical_stock_market.csv',index_col='Date')
my_stocks_df2.index = to_datetime(my_stocks_df2.index)
my_stocks_df_monthly2 = concat([
    my_stocks_df2[0:-4]['Open'].resample('1M').first(),
    my_stocks_df2[0:-4]['High'].resample('1M').max(),
    my_stocks_df2[0:-4]['Low'].resample('1M').min(),
    my_stocks_df2[0:-4]['Close'].resample('1M').last(),
    my_stocks_df2[0:-4]['Adj Close'].resample('1M').last(),
    my_stocks_df2[0:-4]['Volume'].resample('1M').sum()
],axis=1)
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
