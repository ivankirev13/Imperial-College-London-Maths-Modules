test = {
  'name': 'question 3iif',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (stocks_df3 == my_stocks_df3).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(stocks_df3.index,core.indexes.datetimes.DatetimeIndex)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
from pandas import read_csv, to_datetime, core, concat
my_stocks_df2 = read_csv('historical_stock_market.csv',index_col='Date')
my_stocks_df2.index = to_datetime(my_stocks_df2.index)
my_stocks_df3 = my_stocks_df2.copy()
my_stocks_df3['Rise/fall'] = my_stocks_df3['Close'] - my_stocks_df3['Open']
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
