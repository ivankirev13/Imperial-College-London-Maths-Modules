test = {
  'name': 'question 1ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (ser1 == Series(cos(arange(0.0, 2*pi+pi/12, pi/12)))).all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list(ser1.index)
          [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import arange, cos, pi\nfrom pandas import Series',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
