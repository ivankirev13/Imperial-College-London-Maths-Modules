test = {
  'name': 'question 2c',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (ev_series == pd.DataFrame(list(planet_data.values()), index=list(planet_data.keys()))['escape_velocity']).all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list(ev_series.index) == list(planet_data.keys())
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
mercury_data = {'radius' : 2.4e6, 'mass' : 3.3e23, 
    'escape_velocity' : 4.3e3}
venus_data = {'radius' : 6.1e6, 'mass' : 4.9e24, 
    'escape_velocity' : 1.0e4}
earth_data = {'radius' : 6.3e6, 'mass' : 6.0e24, 
    'escape_velocity' : 1.1e4}
mars_data = {'radius' : 3.4e6, 'mass' : 6.4e23, 
    'escape_velocity' : 5.0e3}
jupiter_data = {'radius' : 6.9e7, 'mass' : 1.9e27, 
    'escape_velocity' : 6.0e4}
saturn_data = {'radius' : 5.7e7, 'mass' : 5.6e26, 
    'escape_velocity' : 3.6e4}
uranus_data = {'radius' : 2.5e7, 'mass' : 8.7e25, 
    'escape_velocity' : 2.2e4}
neptune_data = {'radius' : 2.5e7, 'mass' : 1.0e26, 
    'escape_velocity' : 2.4e4}
planet_data = {
    'mercury': mercury_data,
    'venus': venus_data,
    'earth': earth_data,
    'mars': mars_data,
    'jupiter': jupiter_data,
    'saturn': saturn_data,
    'uranus': uranus_data,
    'neptune': neptune_data,
}
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
