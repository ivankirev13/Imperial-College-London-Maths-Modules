test = {
  'name': 'question 3iib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (joined_df == my_joined_df).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(joined_df.index,core.indexes.datetimes.DatetimeIndex)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
from pandas import read_csv, to_datetime, core
my_stocks_df2 = read_csv('historical_stock_market.csv',index_col='Date')
my_stocks_df2.index = to_datetime(my_stocks_df2.index)
my_stocks_max = my_stocks_df2.cummax()
my_stocks_max = my_stocks_max.rename(columns = lambda x: 'Max '+x)
my_joined_df = pd.concat([my_stocks_df2, my_stocks_max],axis=1)
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
