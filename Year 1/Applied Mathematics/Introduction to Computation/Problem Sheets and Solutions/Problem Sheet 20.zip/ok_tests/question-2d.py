test = {
  'name': 'question 2d',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> list(planets_df['orbital_radius'])
          [0.39, 0.72, 1.0, 1.5, 5.2, 9.5, 19.0, 30.0]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
