test = {
  'name': 'question 3ia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (stocks_df == my_stocks_df).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list(stocks_df.index) == list(my_stocks_df.index)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
from pandas import read_csv
my_stocks_df = pd.read_csv('historical_stock_market.csv')
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
