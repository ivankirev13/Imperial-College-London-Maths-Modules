test = {
  'name': 'question 1id',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (poly_ser == pd.Series(polyhedra)).all()
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
polyhedra = {'platonic': 5,'archimedean': 13,'catalan': 13,'johnson (simple)': 28,'johnson': 92,'kepler-poinsot': 4}
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
