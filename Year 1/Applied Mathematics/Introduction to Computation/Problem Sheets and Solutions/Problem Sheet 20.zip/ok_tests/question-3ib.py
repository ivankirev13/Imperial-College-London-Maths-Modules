test = {
  'name': 'question 3ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (stocks_df2 == my_stocks_df2).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list(stocks_df2.index) == list(my_stocks_df2.index)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
from pandas import read_csv
my_stocks_df2 = read_csv('historical_stock_market.csv',index_col='Date')
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
