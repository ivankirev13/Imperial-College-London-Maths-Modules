test = {
  'name': 'question 1iia',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (footballers_df == pd.DataFrame(footballers_dict)).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list(footballers_df.index)
          [0, 1, 2]
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
footballers_dict = {'Position':('goalkeeper','left back','centre half'), 'Name':('Aisha','Esme','Colin'), 'Age':(15,14,15)}
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
