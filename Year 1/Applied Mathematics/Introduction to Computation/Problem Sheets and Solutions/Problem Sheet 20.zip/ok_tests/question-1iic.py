test = {
  'name': 'question 1iic',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (footballers_df3 == DataFrame(footballers_dict).set_index('Position').sort_values('Name')).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> list(footballers_df3.index)
          ['goalkeeper', 'centre half', 'left back']
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
from pandas import DataFrame
footballers_dict = {'Position':('goalkeeper','left back','centre half'), 'Name':('Aisha','Esme','Colin'), 'Age':(15,14,15)}
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
