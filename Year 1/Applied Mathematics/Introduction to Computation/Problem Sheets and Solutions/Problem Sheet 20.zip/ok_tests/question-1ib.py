test = {
  'name': 'question 1ib',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> allclose(array(ser1), cos(arange(0.0, 2*pi+pi/12, pi/12)))
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> allclose(array(ser1.index),arange(0.0, 2*pi+pi/12, pi/12))
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import arange, cos, pi, allclose, array\nfrom pandas import Series',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
