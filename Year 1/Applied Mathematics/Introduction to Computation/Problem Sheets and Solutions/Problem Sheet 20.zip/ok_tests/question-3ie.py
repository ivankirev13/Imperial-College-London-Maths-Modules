test = {
  'name': 'question 3ie',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> (stocks_rollingmeans[2:] == my_stocks_rollingmeans[2:]).all().all()
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> isinstance(stocks_rollingmeans.index,core.indexes.datetimes.DatetimeIndex)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': """
from pandas import read_csv, to_datetime, core
my_stocks_df2 = read_csv('historical_stock_market.csv',index_col='Date')
my_stocks_df2.index = to_datetime(my_stocks_df2.index)
my_stocks_rollingmeans = my_stocks_df2.rolling(3).mean()
	  """,
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
