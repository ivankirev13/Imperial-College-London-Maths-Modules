test = {
  'name': 'question 2f',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> isclose(mass_rad_cov, 1.4745941249999998e+34)
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from numpy import isclose',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}